/*!
 * @file Adafruit_MCP23X08.cpp
 */

#include "Adafruit_MCP23X08.h"

/**************************************************************************/
/*!
  @brief default ctor.
*/
/**************************************************************************/
Adafruit_MCP23X08::Adafruit_MCP23X08() { pinCount = 8; }